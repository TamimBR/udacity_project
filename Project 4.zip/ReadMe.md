This program is a catalog app that stores sports item in a database and allow users to show, edit and delete items.
The main source code of this program is titled "P4.py"

To execute the program run:
python3 P4.py

the app is run on server localhost:8000